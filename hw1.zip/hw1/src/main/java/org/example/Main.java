package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        //enable assertions
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        classLoader.setDefaultAssertionStatus(true);

        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, Object>> rowList = new ArrayList<Map<String, Object>>();
        try(BufferedReader br = new BufferedReader(new FileReader("src/test/resources/downloads.txt"))){
            String line;
            while((line = br.readLine()) != null){
                Map<String, Object> map = mapper.readValue(line, Map.class);
                rowList.add(map);
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        Map<String, Integer> sanFranShowDownloadsMap = new HashMap<>();
        Map<String, Integer> deviceDownloadsMap = new HashMap<>();
        Map<String, Integer> showPrerollOppsMap = new HashMap<>();
        for(Map<String, Object> map : rowList){
            Map<String, Object> downloadIdentifierMap = (Map<String, Object>) map.get("downloadIdentifier");
            String showIdString = (String) downloadIdentifierMap.get("showId");
            String cityString = (String) map.get("city");
            String deviceTypeString = (String) map.get("deviceType");

            Integer adPrerollOppsCount = 0;
            List<Map<String, Object>> opportunitiesList = (List<Map<String, Object>>) map.get("opportunities");
            for(Map<String, Object> opp : opportunitiesList){
                Map<String, Object> positionUrlSegmentsMap = (Map<String, Object>) opp.get("positionUrlSegments");
                List<String> adBreakIndexList = (List<String>) positionUrlSegmentsMap.get("aw_0_ais.adBreakIndex");
                if(adBreakIndexList.contains("preroll")){
                    adPrerollOppsCount += 1;
                }
            }

            // count downloads for san fran shows
            if(cityString.equals("san francisco")){
                increaseCountForKeyInMap(sanFranShowDownloadsMap, showIdString);
            }

            // count downloads for devices
            increaseCountForKeyInMap(deviceDownloadsMap, deviceTypeString);

            // count preroll opportunities for each show
            if(!showPrerollOppsMap.containsKey(showIdString)){
                showPrerollOppsMap.put(showIdString, adPrerollOppsCount);
            }
            else{
                showPrerollOppsMap.put(showIdString, showPrerollOppsMap.get(showIdString) + adPrerollOppsCount);
            }
        }

        // find most popular show in san fran
        String mostPopularShow = "";
        Integer mostDownloads = 0;
        for(String show: sanFranShowDownloadsMap.keySet()){
            Integer numOfDowns = sanFranShowDownloadsMap.get(show);
            if(numOfDowns > mostDownloads){
                mostPopularShow = show;
                mostDownloads = numOfDowns;
            }
        }

        // find most popular device
        String mostPopularDevice = "";
        Integer mostDownloadsOnDevice = 0;
        for(String device: deviceDownloadsMap.keySet()){
            Integer numOfDowns = deviceDownloadsMap.get(device);
            if(numOfDowns > mostDownloadsOnDevice){
                mostPopularDevice = device;
                mostDownloadsOnDevice = numOfDowns;
            }
        }

        // asserts
        assert mostPopularShow.equals("Who Trolled Amber");
        assert mostDownloads == 24;
        assert mostPopularDevice.equals("mobiles & tablets");
        assert mostDownloadsOnDevice == 60;
        assert showPrerollOppsMap.get("Stuff You Should Know") == 40;
        assert showPrerollOppsMap.get("Who Trolled Amber") == 40;
        assert showPrerollOppsMap.get("Crime Junkie") == 30;
        assert showPrerollOppsMap.get("The Joe Rogan Experience") == 10;


        // print
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Most popular show is: " + mostPopularShow);
        System.out.println("Number of downloads is: " + mostDownloads);
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Most popular device is: " + mostPopularDevice);
        System.out.println("Number of downloads is: " + mostDownloadsOnDevice);
        System.out.println("--------------------------------------------------------------------------------");
        for(String key: showPrerollOppsMap.keySet()){
            System.out.println("Show Id: " + key + ", Preroll Opportunity Number: " + showPrerollOppsMap.get(key));
        }
    }

    private static void increaseCountForKeyInMap(Map<String, Integer> map, String key){
        if(!map.containsKey(key)){
            map.put(key, 1);
        }
        else{
            map.put(key, map.get(key) + 1);
        }
    }


}